export interface Products {
    id : number
    title : string
    price : number
    image : string
}
