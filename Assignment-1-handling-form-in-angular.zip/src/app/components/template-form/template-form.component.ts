import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'assignment-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {

  constructor() { }

  form = {
    email : '',
    fullname : '',
    phoneno : '',
    password : '',
    confirmpassword : '',
    terms : false
  }

  ngOnInit(): void {
  }

  userRegistration(){
    console.log(this.form);
  }

}
