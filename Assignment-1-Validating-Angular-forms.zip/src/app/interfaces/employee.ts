export interface Employee {
    employeeid : string,
    firstname:string,
    lastname:string,
    salary: string,
    dob: string,
    email: string,
    showEdit?: boolean
}
