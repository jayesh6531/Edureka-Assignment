import { MatchPasswordDirective } from './match-password.directive';

describe('MatchPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new MatchPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
