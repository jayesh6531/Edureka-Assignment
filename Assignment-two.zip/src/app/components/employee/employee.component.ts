import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/interfaces/employee';

const employeedata = [{
  employeeid : "S100",
  firstname:"Jayesh",
  lastname: "Shamnani",
  salary: "40000",
  dob: "19/11/1993",
  email: "jayeshshamnani@gmail.com"
},
{
  employeeid : "S200",
  firstname:"Jaya",
  lastname: "Sharma",
  salary: "30000",
  dob: "19/11/1994",
  email: "jayasharma@gmail.com"
},
]

@Component({
  selector: 'assignment-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  public isshowEdit : boolean = false;
  public isShowHide : boolean = true;

  public EmployeeInfo : Employee[] = employeedata;  

  constructor() { }

  ngOnInit(): void {
  }

  EditEmp(){
    this.isshowEdit = true;
    this.isShowHide = false;
  }

  UpdateEmp(){
    this.isshowEdit = false;
    this.isShowHide = true;
  }

}
