export interface Employee2 {
    employeeid:string,
    name:string,
    salary:string,
    age:string
}
